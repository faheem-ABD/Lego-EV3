# Runestone 2023 - Group E

# Members

- Ganeshkumar Pandiarajan

- Tran Tan Dung

- Douglas Gådin

- Tran Duc Huy

- Petter Jerndal

- Faheem Abdeen Kulam Magdoom

- Tran Phuc Thanh

- Johan Winman

## Project

- Project URL: https://github.com/orgs/runestone2023/projects/3
- Project board: (currently pending)

## IDE

We have decided to use Visual Studio Code as our IDE because it is widely used and can be easily integrated with Git. You can download the installation file for your operating system (Windows, macOS, or Linux) from the official VSCode website (https://code.visualstudio.com/), and then follow the installation prompts to complete the process.

## Communication

For communication we are using Discord and Zoom. We have scheduled standups at times convenient for all

## Useful links

- Runestone 2023 Team Information: https://docs.google.com/spreadsheets/d/1DP3LjqU5jQ4zQHnGcaK-rB72ttCNpHUKazJ-S8geKTs/edit#gid=2007966978

- Runestone 2023 Trello Link: https://trello.com/w/runestone2023

- Development Tools Workshop Lecture: https://uppsala.instructure.com/courses/66448/files/4861733/download

- Team Contract: https://docs.google.com/document/d/15_FFz9jD9s6f4SDYJ8P5a1TKAuOmk1R_ZFpwPkwgIbI/edit#

