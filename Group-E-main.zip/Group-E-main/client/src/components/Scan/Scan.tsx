import React from "react";

const Scan = () => {
  return <div>Scan</div>;
};

export default Scan;
