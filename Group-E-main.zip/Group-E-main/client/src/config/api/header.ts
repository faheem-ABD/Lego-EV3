export const HEADERS = {
  header: () => ({
    accept: "application/json",
    "Content-Type": "application/json; charset=UTF-8",
  }),
};
